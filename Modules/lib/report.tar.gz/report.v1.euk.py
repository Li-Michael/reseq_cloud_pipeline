#!/usr/bin/env python
# -*- coding: UTF=8 -*-
import sys
import mhtml_v3
html_main = mhtml_v3.simple_main(title="重测序项目基本分析结果")
#sampleinfo = sys.argv[1]

sns = []
f = file(sys.argv[1],"r")
for line in f:
	if line.startswith("#"):continue
	arr = line.rstrip("\n").split("\t")
	sns.append(arr[0])
f.close()

html_main.add_honor_title("重测序项目基本分析结果")
statdir = './HELP/'
html_main.add_enter()
html_main.add_head_color("一、重测序项目生物信息分析基本流程", headlevel = 2)
html_main.add_line()
html_main.add_content(""">>> step 1. 下机数据质量控制，评估测序数据的可靠性""")
html_main.add_content(""">>> step 2. 将下机数据（reads）采用比对基因组，评估覆盖效率及测序深度""")
html_main.add_content(""">>> step 3. SNV(SNP/Short INDEL)检测和注释""")
html_main.add_content(""">>> step 4. 结构变异SV检测 """)
html_main.add_content(""">>> step 5. 拷贝数变异CNV检测""")
html_main.add_content(""">>> step 6. 群体分析""")
html_main.add_content_retract("""[1] 本项目结题报告中正文内容蓝色字体均为文件超级链接，点击可查看或者下载。""")
html_main.add_content_retract("""[2] 建议使用较新版本的火狐（Mozilla Firefox）浏览器、Google Chrome浏览器、Safari浏览器查看本项目结题报告，其他浏览器可能会由于页面代码不兼容而导致报告内容异常。""")

#statdir = './0.info/sampleinfo.xls'
html_main.add_head_line()
html_main.add_enter()
html_main.add_head_color("二、本项目实验设计",headlevel = 2)
html_main.add_line()
html_main.add_content(""">>> 本项目实验设计基本情况如下表所示：""")
#tmptable,tmpnote = mhtml_v3.xls2table("%s"%sampleinfo)
html_main.add_locate(str(tmptable))
html_main.add_enter()
html_main.add_head_line()

html_main.add_head_color("三、结果展示及说明",headlevel = 2)
html_main.add_line()
html_main.add_head_color("1 测序数据进行数据过滤后质量评估", headlevel = 3)
html_main.add_content(""">>> 对下机的原始数据，进行数据质量评估,评测结果:(以一个样本为例)""")

filter_stat = "./filter/output/filter_stat.xls"
filtertable, filternote = mhtml_v3.xls2table("%s"%filter_stat)
html_main.add_locate(str(filtertable))

html_main.add_content("*说明：*")
html_main.add_content_retract("""每个样本测序量均达到合同要求，且Q20，Q30指标也符合要求，测序原始数据的质量较好。""")
html_main.add_enter()
html_main.add_head_line()

statdir = "2.mappingQC"
html_main.add_head_color("2 基因组比对情况统计", headlevel = 3)
html_main.add_content(">>> 序列比对背景及目的：")
html_main.add_content_retract("使用短序列比对软件bwa,将测序reads 比对到参考基因组上，bwa 具有快速、准确等特性，在重测序领域广泛使用。采用mem命令，其在比对大于70bp的数据时，具有较高的准确率。")
html_main.add_content(">>> 参考文献：")
html_main.add_content_retract("[1] Li, H. and Durbin, R. (2009) Fast and accurate short read alignment with Burrows-Wheeler transform, Bioinformatics, 25, 1754-1760.")
html_main.add_content(">>> 所使用软件参数:")
html_main.add_content_retract("[1] bwa, v.0.7.9, 参数：mem  -T 30 -h 5  -M ")
html_main.add_content(">>> 序列比对结果统计：比对结果以bam格式保存，项目交付后可申请下载（数据庞大）")
html_main.add_content_retract("""[1] 样本比对基因组统计结果如下表所示: """)
tmptable,tmpnote = mhtml_v3.xls2table("./report/mapping/MappingQC_stat.xls")
html_main.add_locate(str(tmptable))

html_main.add_enter()
html_main.add_head_line()

statdir = "3.variants"
html_main.add_head_color("3 单核苷酸碱基多态性（SNP）及短片段插入缺失多态性（InDel）检测", headlevel = 3)
html_main.add_content(">>> 3.1 变异检测背景及目的：")
html_main.add_content_retract("一个物种内，不同个体间存在着大量的可遗传的多态性标记，通过观察及分析群体内的多态性遗传标记，有如下几个较重要的应用：如遗传图谱构建、种群结构与环境适应性分析、全基因组关联分析、数量或质量性状定位、分子辅助育种等等。可直接或间接的找到控制目标性状的基因或功能区域。")
html_main.add_content_retract("""此处，主要进行单核苷酸碱基多态性（<a href="https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism">SNP</a>）位点和短片段插入缺失多态性（<a href="https://en.wikipedia.org/wiki/Indel">InDel</a>）检测。""")
html_main.add_content(">>> 多态性位点的鉴定:")
html_main.add_content_retract("""[1] 多态性位点鉴定：采用GATK检测单核苷酸碱基突变SNPs (Single-nucleotide polymorphism)及短序列插入缺失突变(Insertions and Deletions)""")
html_main.add_content_retract("""为了降低检测到的变异的假阳性, 对碱基质量>13 (base quality >13)及比对分值大于20的序列(Mapping Quality > 20)的测序数据。""")
html_main.add_content_retract("""[2] SNP InDel 鉴定采用软件：GATK的HaplotypeCaller/GenotypeGVCFs/SelectVariants工具进行SNP/INDEL的cohort calling，VariantFiltration工具对vcf进行过滤。参数:calling过程采用默认参数，可以根据项目情况进行调整; 
SNP过滤参数为：--clusterSize 3 --clusterWindowSize 10 -maskExtend 3 --filterName "highMQRankSum" --filterExpression "MQRankSum > -12.5" --filterName "lowFS" --filterExpression "FS < 20.0"  --filterName "highReadPosRankSum" --filterExpression "ReadPosRankSum > -8.0" --filterName "highMQ"  --filterExpression "MQ > 40.0" --filterName "highQD"  "--filterExpression "QD > 2.0"  --genotypeFilterName "highDP" --genotypeFilterExpression "DP > 8.0"；INDEL的过滤参数为：--filterExpression "MQ > 40.0" --filterName "highMQRankSum" --filterExpression "MQRankSum > -12.5"  --genotypeFilterExpression "DP > 8.0"。""")

html_main.add_content(""">>> SNP分析结果及说明：""")
html_main.add_content_retract("采用上述方法鉴定SNP及INDEL,鉴定到SNP及INDEL多态性位点及各样本基因型结果:""")
html_main.add_content_retract("""[1] 鉴定到的所有的SNP位点: <a href="%s/report/GATK/total.snp.fmt.xls">请点击查看</a>"""%(statdir))
html_main.add_content_retract("""[2] 鉴定到的所有的INDEL位点: <a href="%s/total.indel.fmt.xls">请点击查看</a>"""%(statdir))
html_main.add_content_retract("""* 文件结果说明: <a href="HELP/variant/var_mat.html">请点击查看</a>""",2)
html_main.add_enter()
html_main.add_content(">>> 3.2 SNP突变频谱分析：")
html_main.add_content_retract("""单核苷酸碱基突变包含如下6种基本类型： C>A/G>T（互补原则）, C>G/G>C, C>T/G>A, T>A/A>T,T>C/A>G, T>G/A>C，又可以根据发生替换的碱基类型分成2大类，嘌呤和嘧啶间的替换称为颠换（transversion），嘌呤与嘌呤之间或嘧啶与嘧啶之间的替换称为转换（transition）。根据各类型的点突变的数量，对样本进行聚类分析，可以观察样本在点突变水平上的相似程度，不同遗传背景或不同性状样本（如癌症的体细胞突变）一般会呈现聚类现象""")
html_main.add_content("分析结果如下：")
html_main.add_content_retract("[1] SNP突变类型数目汇总统计:")
html_main.add_locate("""<img src="%s/total_snp_substitution.png" width="65%%" /><a href="%s/total_snp_substitution.svg">SVG矢量图</a>"""%(statdir,statdir))
html_main.add_content_retract("[2] SNP突变频谱，堆积图")
html_main.add_locate("""<img src="%s/SNP_substitution_pattern.png" width="65%%" /><a href="%s/SNP_substitution_pattern.svg">SVG矢量图</a>"""%(statdir,statdir))
html_main.add_content_retract("""[3] 对应的表格: """)
tmptable,tmpnote = mhtml_v3.xls2table("%s/Mutation_pattern.xls"%statdir)
html_main.add_locate(str(tmptable))
html_main.add_content(tmpnote)
html_main.add_content_retract("[4] SNP突变频谱及样本聚类结果")
html_main.add_locate("""<img src="%s/SNP_substitution_Mutation_Spectrum.png" width="65%%" /><a href="%s/SNP_substitution_Mutation_Spectrum.svg">SVG矢量图</a>"""%(statdir,statdir))
html_main.add_enter()

statdir = "4.SNVanno"
html_main.add_head_color("4 遗传系突变位点功能注释", headlevel = 3)
html_main.add_content(""">>> 生殖系突变germline mutation是指在生殖细胞中发生的任何可检测、可遗传的突变。在生殖细胞系以外的细胞中发生的突变称为体细胞突变，体细胞突变不能遗传自亲本，也不能传递给后代。一般检测的血液样本为生殖系突变，而同一样本，癌症病变组织与癌旁正常组织间的差异为体细胞突变。因此对各突变位点的功能注释能有效的提供该位点突变的功能线索。""")
html_main.add_content_retract("""(1) 对于人类：注释包括如下数据库,基于refGene对变异位点所在的区域进行注释；该变异位点相关的转录本；描述 UTR、splicing、ncRNA_splicing 或 intergenic 区域的变异情况；外显子区的 SNV or InDel 变异类型；氨基酸改变情况；dbSNP144数据库；千人东亚人种突变频率分析；突变有关的临床意义注释；癌症突变数据库；突变所在功能保守域；预测是否突变会导致新的剪切位点AdaBoost算法；预测是否突变会导致新的剪切位点random forest算法；国家心肺和血液研究所外显子组测序计划 NHLBI-ESP项目6500外显组的ALT等位基因频率；ExAC 65000 exome allele frequency；haplotype群体频率；34个外显子项目已知突变位点频谱；NCI-60 human tumor cell line频谱；GWAS相关位点注释；重复序列注释信息；CpG 岛区域注释；miRBase小RNA突变注释；大片段重复序列注释；基因组结构变异数据库；以及蛋白危害性及突变位点保守性打分""")
html_main.add_content_retract("""(2) 非人类样本：仅注释embl 基因结构（即ensGene）""")
html_main.add_content(""">>> 注释结果：详细说明请点击<a href="./HELP/variant/human_var_anno.readme.rtf">查看</a>""")
html_main.add_content_retract("""[1] 对生殖系点突变进行功能注释，所有位点的注释结果见：<a href="%s/total.snp.fmt.test_multianno.txt.xls">点击查看</a>"""%statdir)
html_main.add_content_retract("""[2] 分样本注释结果路径：<a href="%s/">点击查看</a>"""%statdir)
html_main.add_content_retract("""[3] 各样本Gene区域注释情况汇总,类型说明:<a href="./HELP/variant/refgene_annotation.readme.html">查看</a>""")
html_main.add_locate("""<img src="%s/Annotation_Type_stat.png" width="65%%" /><a href="%s/Annotation_Type_stat.svg">SVG矢量图</a>"""%(statdir,statdir))
html_main.add_content_retract("""上图对应的表格：<a href="%s/SNP.anno.stat.xls">点击查看</a>"""%statdir)
html_main.add_enter()

statdir = "5.INDELanno"
html_main.add_head_color("5 遗传系InDel突变位点功能注释", headlevel = 3)
html_main.add_content(""">>> 遗传系InDel 与遗传系突变来源类似。同样对这些突变进行了上述功能注释，结果如下：""")
html_main.add_content_retract("""[1]  对生殖系InDel进行功能注释，所有位点的注释结果见：<a href="%s/total.indel.fmt.test_multianno.txt.xls">点击查看</a>"""%statdir)
html_main.add_content_retract("""[2] 分样本注释结果路径：<a href="%s/">点击查看</a>"""%statdir)
html_main.add_content_retract("""[3] 各样本Gene区域注释情况汇总,类型说明:<a href="./HELP/variant/refgene_annotation.readme.html">查看</a>""")
html_main.add_locate("""<img src="%s/Annotation_Type_stat.png" width="65%%" /><a href="%s/Annotation_Type_stat.svg">SVG矢量图</a>"""%(statdir,statdir))
html_main.add_content_retract("""上图对应的表格：<a href="%s/SNP.anno.stat.xls">点击查看</a>"""%statdir)
html_main.add_enter()

statdir = "6.CNV"
html_main.add_head_color("6 基因组范围内拷贝数变异检测", headlevel = 3)
html_main.add_content(""">>> CNV（copy number variations）指基因组上1kb-5Mb级别之间的DNA片段拷贝数变异；已知一半的CNV与coding区域有重叠，这些变异直接影响CNV区域的基因剂量补偿，影响基因表达水平、很多CNV与许多性状有关，如水稻粒长、品质。人类疾病，如癌症、自闭症等复杂疾病有关。""")
html_main.add_content_retract("""采用RD(read depth)-based 方法检测拷贝数变异。大致过程如下：a) 计算基因组上每个窗口范围内的RD水平 b)校正，考虑GC含量引入的偏差 c)拷贝数估计，并计算gain和loss区域 d) 将拷贝数相同的区域合并到一起。一般对 单样本 或 成对样本（case/control）检测CNV，后者的假阳性率远低于前者。""")
html_main.add_content(">>> CNV区域鉴定：")
html_main.add_content_retract("""采用Control-FREEC v7.0, 参数：window=1000, degree=3, intercept=1""")

html_main.add_content(">>> 参考文献：")
html_main.add_reference("""[1] Boeva, V., et al. (2011) Control-free calling of copy number alterations in deep-sequencing data using GC-content normalization, Bioinformatics, 27, 268-269. """)

html_main.add_content(">>> 结果及说明：")
html_main.add_content_retract("""[1] CNV区域检测结果:""")
for sn in sns:
	html_main.add_content_retract("""样本%s, 其检测到的CNV区域结果：<a href="%s/%s/CNV.xls">点击查看</a>"""%(sn,statdir,sn),2)
	html_main.add_content_retract("""样本%s, 其检测到的CNV区域展示图：<a href="%s/%s/all_region.png">点击查看</a>"""%(sn,statdir,sn),2)
	html_main.add_content_retract("""样本%s, 过滤repeat区域后的CNV区域展示图：<a href="%s/%s/all_region.png">点击查看</a>"""%(sn,statdir,sn),2)
	html_main.add_enter()	
html_main.add_enter()

statdir = "7.SV"
html_main.add_head_color("6 基因组范围内结构变异检测", headlevel = 3)
html_main.add_content(""">>> 此项目的目的：希望回答3个问题：1）转基因片段是否整合到了目标基因组上。2）它插入到了基因组上哪个精确的位置。3）所转的基因是否是完整的整合到目标基因组上的""")
html_main.add_content(">>> 方法说明：使用breakdancer 来查找整合的片段大概的位置，使用默认参数。通过自主开发的程序找到精确的插入位点。")
html_main.add_content_retract("""分析基本流程，见下图：""")
html_main.add_locate("""<img src="./HELP/variant/virus_genome_scan.png" width="65%" />""")
html_main.add_content(""">>> 插入片段检测结果：""")
html_main.add_content_retract("""[1] 插入位点识别结果：<a href="%s/rice_plasmid_SV.xlsx">点击查看</a>"""%statdir)
for sn in sns:
	html_main.add_content_retract("""样本%s, 其检测到的基因组整合位点关系图: <a href="%s/%s.insert.svg">点击查看</a>"""%(sn,statdir,sn))
	html_main.add_content_retract("""样本%s, plasmid 转基因片段测序reads（即整合到基因组上的片段）覆盖图: <a href="%s/%s.insert.svg">点击查看</a>"""%(sn,statdir,sn))
html_main.add_enter()
html_main.add_enter()

#statdir = "6.associate"
#html_main.add_head_color("6 遗传系突变位点同性状关联分析", headlevel = 3)
#html_main.add_content(""">>> 基于样本的SNP数据与目标性状（如疾病状态等），筛选同目标性状有关的遗传标记位点，从而找到和目标性状有关的功能位点。此处，为家系数据。其中，目前已知的具有健康样本的家系仅仅有XT样本，因此，我们仅对XT样本进行该项分析""")

html_main.add_enter()

html_main.add_head_color("四、附录", headlevel = 2)
html_main.add_line()
html_main.add_head_color("1 基因组文件来源说明", headlevel = 3)
html_main.add_content(""">>> 基因组文件：Oryza_sativa.IRGSP-1.0.27.dna_sm.toplevel.fa；下载网站: EMBL, ftp.ensemblgenomes.org""")

with open('reseq_basic_analysis_v3.html', 'w') as fp:
	fp.write(html_main.str_top(height = 400,width=600))
